function generatePlayer() {
    // create player and save his data to localStorage.
    // player has the following attributes:
    /*
        1. name - string
        2. hp - hit points (number)
        3. gold - number
        4. strength
    */
}

generatePlayer();