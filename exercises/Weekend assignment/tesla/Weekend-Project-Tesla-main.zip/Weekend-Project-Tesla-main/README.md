# Weekend Project Tesla

## Description

(👉 ﾟヮﾟ)👉 👈(ﾟヮﾟ 👈)

In this project I created a mock of Tesla Model 3 web page as part of my second weekend project in appleseeds bootcamp.

The purpose of this task was implements everything we learned in the course until now.

In order to achive the goal I used HTML for building the web page and CSS for styling.
I used SVG's files in some places on the web page (which were a bit challenging) and also flexbox for items alignment.

One of the tasks was making a responsive site, so I apply it by using media query for some screen sizes (at significant points).

Additional work in the future includes implement animation.

---

## Preview:

<img src="https://github.com/shirtol/Weekend-Project-Tesla/blob/main/images/preview/preview.png?raw=true" height="270" width="480" />
