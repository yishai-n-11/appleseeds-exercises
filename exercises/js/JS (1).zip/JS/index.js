console.log(this);
