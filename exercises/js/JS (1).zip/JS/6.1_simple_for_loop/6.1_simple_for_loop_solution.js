for (let voter = 1; voter <= 50; voter++)
  console.log(`Voter number ${voter} is currently voting`);
