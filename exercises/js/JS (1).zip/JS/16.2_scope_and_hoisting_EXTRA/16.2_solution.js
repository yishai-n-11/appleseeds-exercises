//! 1
//* 10
//* 20
//* 20

//! 2
//* 10
//* 20
//* 10

//! 3
//* 10
//* 20
//* 30
//* 20
//* 10

//! 4
//* test();
//* undefined

//! 5
//* undefined
//* undefined
//* 100

//! 6
//* foo
//* error - bar is not defined
