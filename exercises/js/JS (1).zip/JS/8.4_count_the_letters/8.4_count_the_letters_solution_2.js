const array = ['Hello', 'Good Day', 'Your Welcome', 'hotdog', 'hamburgers'];
console.log(array.join(''));

// let obj = {};
// let largest = 0;
// array.join('').toLocaleLowerCase()
//   .split('')
//   .forEach((l) => {
//     if (l !== ' ') {
//       l !== ' ' && obj[l] ? obj[l]++ : (obj[l] = 1);
//     }
//     obj[l] > largest && largest++;
//   });
// console.log(obj);
// // console.log(array.join);

const person = {
  first: 'mor',
  last: 'ben',
  fun() {
      const 
  },
};
