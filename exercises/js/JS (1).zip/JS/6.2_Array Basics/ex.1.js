const func = () => {
  return 'hola';
};

console.log(func());
